clear all
close all
clc
rand('seed',1);randn('seed',1);
m=3;n=10;K=2;
N=round(n.^[1:0.2:3]);N_anneal=20;

in.T=10000;
in.IC='BIC';
in.K=K;
in.eps1=0;
in.eps2=0;
in.A=[];
in.b=[];
in.Aeq=[];
in.beq=[];
in.P_init=[];
in.MaxIter=500;
in.tol=1e-6;
for i=8:length(N)
    i
    in.N_alphaX=N(i);
    in.tol=1e-6*in.N_alphaX*m;


    for k=13:N_anneal
        clear N_cd P
        N_cd=round(10*rand(m,N(i)));P=0*N_cd;
        in.N_cd_old=N_cd;
        for j=1:N(i)
            P(:,j)=N_cd(:,j)./(sum(N_cd(:,j)));
        end
        in.gamma_init=zeros(in.K,in.N_alphaX);
        for t=1:in.N_alphaX
            rr=ceil(in.K*rand(1));
            in.gamma_init(rr,t)=1;
        end
        in.P_init=zeros(m,in.K);
        for t=1:in.K
            rr=ceil(in.K*rand(1));
            in.gamma_init(rr,t)=1;
        end
        in.H_g=zeros(in.K*in.N_alphaX);
        tic;%[IDX,C]=kmeans(P',K);
        [out]=AdaptiveBoxDiscretization_H1_v2(in);
        t_dbmr(i,k)=toc;
        if and(i==1,k==3)
            t_dbmr(1,1:2)=t_dbmr(1,3);
        end
        acf{i,k}=out.acf;N_iter(i,k)=length(out.acf);
        tic;[ ~,~, ~] = nnmf_Bayes_constrained_v2(P,2);t_v2(i,k)=toc;
        tic;[ ~,~, ~] = reduce_Bayes_constrained_v2(N_cd,2);t_red(i,k)=toc;
        tic;[ ~,~, ~] = reduce_Bayes_constrained_exact(N_cd,2);t_ex(i,k)=toc;
    end
end
%i=9;
figure;plot(N(1:i),mean(t_dbmr(1:i,:)'));
figure;plot(N(1:i),mean(N_iter(1:i,:)'));

figure;semilogy(N(1:i),mean(t_dbmr(1:i,:)'),'b+');hold on;semilogy(N(1:i),mean(t_ex(1:i,:)'),'r>');semilogy(N(1:i),mean(t_red(1:i,:)'),'c<');semilogy(N(1:i),mean(t_v2(1:i,:)'),'gx');
