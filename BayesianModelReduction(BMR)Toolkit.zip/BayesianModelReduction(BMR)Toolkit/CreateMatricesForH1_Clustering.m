function [H,A,b,Aeq,beq,H_D] = CreateMatricesForH1_Clustering(X,N_X,K)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
H=zeros(N_X*K);D=zeros(N_X);
for i=1:N_X
    for j=1:N_X
       D(i,j)=KernelDistance(X(:,i),X(:,j));%exp(-sum((X(:,i)-X(:,j)).^2)); 
    end
end
D=D-diag(diag(D));
H_D=diag(sum(D,1))-2*D+diag(sum(D,2));%H_D=H_D-diag(diag(H_D));
Aeq=zeros(N_X,N_X*K);
% % H2=zeros(N_X*K);
% % for i1=1:N_X
% %     for k1=1:K
% %         for i2=1:N_X
% %             for k2=1:K
% %                 if k1==k2
% %                    i=(i1-1)*K+k1;j=(i2-1)*K+k2;
% %                     H2(i,j)=2*H_D(i1,i2);
% %                 end
% %             end    
% %         end
% %     end
% % end
        
for i=1:N_X
    for k=1:K
        for j=1:N_X
            H(k+(i-1)*K,k+(j-1)*K)=2*H_D(i,j);
        end
        Aeq(i,k+(i-1)*K)=1;
    end
end
%H=diag(sum(H,1))-2*H+diag(sum(H,2));H=H-diag(diag(H));
A=sparse(-eye(N_X*K));b=sparse(N_X*K,1);beq=ones(N_X,1);
H=sparse(H);Aeq=sparse(Aeq);
