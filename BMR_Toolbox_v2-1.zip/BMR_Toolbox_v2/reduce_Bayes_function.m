function [y] = reduce_Bayes_function(x0,A,n,m,K)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
lambda=reshape(x0(1:m*K),m,K);
Gamma=reshape(x0(1+m*K:m*K+K*n),K,n);
y=-sum(sum(A.*(log(lambda)*Gamma)));

end

