==================================================================
Data-driven Bayesian Model Reduction Toolbox (BMR Toolbox)
(C) 2017 Susanne Gerber and Illia Horenko 
==================================================================

1. Introduction
================
BMR-Toolbox is a Matlab-based software package for a reduction of conditional
 Bayesian models and matrices. It contains the matrix-based algorithms like Nonnegative Matrix Factorization (with matrix stochasticity constraints) as well as the direct matrix-free algorithms described in the following paper:

S. Gerber and I. Horenko, "Towards a direct and scalable identification of reduced 
 models for categorical processes", PNAS, 2017.

 BMR-toolbox is open-sourced (under the General Public Licence), can be easily 
extended or tailored for specific tasks, and scaled up for large data sets.

2. Contents
================

1) “ALA_Data_Analyze.m” - a demo illustrating an application of different methods from this toolbox to the to identification of the reduced model for the categorical time series dynamics of  Ramachandran states from a discretized MD trajectory of torsion
 angles for a 10-ALA plypeptide with a time step tau=100 ps. 

2) “nnmf_Bayes_constrained_penalty.m” - Tykhonov-penalized Non-Negative Matrix Factorization in Frobhenius-norm for the Bayesian causality matrix A, with the matrix stochasticity constraints included as penalty terms (equality and inequality) and with the reduced rank-dimension K:
||A-lambda_f*Gamma_f||+alpha||Id*lambda-1||+beta||Id*Gamma-1|| 
Based on the iterative scheme suggested in a Section 4 ("Application-Dependent Auxiliary Constraints")
of the paper: 
 M. Berry et. al. "Algorithms and applications for approximate nonnegative matrix factorization", Computational Statistics & Data Analysis, 52(1), 155 - 173, 2007. 

3) “nnmf_Bayes_constrained_v2.m” - Matlab function for the NNMF Frobhenius-norm reduction of the Bayesian causality matrix A subject to the matrix stochasticity constraints (equality and inequality).

4) “reduce_Bayes_constrained_v2.m” - Matlab function for the direct optimisation of the approximated log-likelihood function (polynomial in “n”).
5)  “reduce_Bayes_constrained_exact.m” - Matlab function for the direct optimisation of the exact log-likelihood function (polynomial in “n”).
6) “compare_computational_cost.m” - a Matlab demo illustrating a comparison of the computational cost of different algorithms.
7) “DBMR_Algorithm.m” - Matlab function for the iterative DBMR clustering algorithm from the paper (optimising the approximate log-likelihood with a scaling that is linear in “n”)
8) “EDBMR_Algorithm.m” - Matlab function for the iterative maximisation of the exact log-likelihood for reduced model, scaling  is linear in “n”.
9) “compare_computational_cost_with_EM_over_m.m” - computational comparison of PLSA-EM (from Hofmann’99-’01) and DBRM algorithms. Creates a Figure 1 from the paper.
10) “plsa.m” - Matlab implementation of the Probabilistic Latent Semantic Analysis (from Hofmann’99-’01). 
11) All other files contain functions that are called from the programs 1)-9). 

3. Availability
================
For academic uses, BMR-Toolbox is available free of charge. Every usage of the methods 
 from this toolbox in publications should be acknowledged by a citation of the paper
 mentioned above in the “Introduction”.

4. Installation
================
1) Requirements:  MATLAB, version 7.0 and higher; MATLAB Optimisation Toolbox Library. 
2) Download BMR-Toolbox.
3) Create a directory and unzip the downloaded files into this directory.

4. How to start?
==================
1) Start up MATLAB. 
2) Run “ALA_Data_Analyze.m” or “compare_computational_***.m” for demos.


If you have any comments or suggestions then, please, send us an email at
horenkoi@usi.ch and sugerber@uni-mainz.de
