function [P,fff,IC,LogL_cd,N_par,LLL] = PRP_measure_clustering_H1_v2_EDBRM_reg(T,IC,gamma,K,eps1,eps2,N_cd_old,A,b,Aeq,beq,P_init,H_g)

[N_alphaY,N_alphaX]=size(N_cd_old);
N_alphaX_old=N_alphaX;
% if nargin>7
%     [X,alphaX,N_alphaX] = Gamma2X(gamma,X,K,T);
% end
gamma_norm=zeros(1,K);
N_X=N_alphaX;
for k=1:K
    for i=1:N_X
        for j=1:N_X
            gamma_norm(k)=gamma_norm(k)+...
                0.5*eps1*H_g(k+(i-1)*K,k+(j-1)*K)*gamma(k,i)*gamma(k,j);
        end
    end
end


N_cd=zeros(N_alphaY,K);
LogL_cd=zeros(K,N_alphaX_old);
for k=1:K
    for state_i=1:N_alphaY
        for state_j=1:N_alphaX
            N_cd(state_i,k)=N_cd(state_i,k)+gamma(k,state_j)*N_cd_old(state_i,state_j);
        end
    end
end



options=optimset('GradObj','on','Algorithm','sqp','MaxIter',1000,'Display','off','TolFun',1e-12,'TolCon',1e-12,'TolX',1e-12);
xxx0=reshape(P_init',K*N_alphaY,1)';
[~,iii]=find(xxx0<1e-12);xxx0(iii)=1e-12;
%ones(1,N_alphaY*N_alphaX)./(N_alphaY*N_alphaX);
%f0=LogLikPairwiseCausalityRegularized...
%    (xxx0,reshape(N_cd',N_alphaY*N_alphaX,1)',eps2,N_alphaX,N_alphaY,T);
% % P_cd=zeros(N_alphaY,K);
% % for state_j=1:K
% %     N_j=sum(N_cd(:,state_j));
% %     for state_i=1:N_alphaY
% %         P_cd(state_i,state_j)=N_cd(state_i,state_j)./N_j;
% %     end
% % end

[xxx,fff,flag,output] =  fmincon(@(x)LogLikPairwiseCausalityRegularized_SciAdv...
    (x,reshape(N_cd',N_alphaY*K,1)',K,N_alphaY,T,gamma_norm)...
    ,xxx0,(A),(b),Aeq,beq,[],[],[],options);
 % P=P_cd;
P=reshape(xxx,K,N_alphaY)';
for k=1:K
    for t=1:N_alphaX_old
        for state_i=1:N_alphaY
            if P(state_i,k)>1e-13
                LogL_cd(k,t)=LogL_cd(k,t)-log(P(state_i,k)).*N_cd_old(state_i,t);
            else
                LogL_cd(k,t)=LogL_cd(k,t)-log(1e-13).*N_cd_old(state_i,t);
            end
        end
    end
end
N_par=0;npp=zeros(1,N_alphaY);
for state_i=1:N_alphaY
    pp=sort(P(state_i,:),'descend');
    npp(state_i)=length(find(abs(diff(pp))>1e-8))+1;
    N_par=N_par+npp(state_i);
end
xxx=reshape(gamma,1,K*N_alphaX_old);
%[VV,DD]=eig(H_g);
N_par=(N_alphaY-1)*K+0.5*xxx*H_g*xxx';%+0.5*xxx*H_g*xxx';%N_par-min(npp);
LLL=0;
for t=1:N_alphaX_old
    for k=1:K
    LLL=LLL-gamma(k,t)*LogL_cd(k,t);
    end
end
if strcmp(IC,'BIC'),
    IC=-2*LLL+N_par*(log(T));%+2*N_par_cd;%+2*N_par_cd*(N_par_cd+1)/(T-N_par_cd-1);%-log(2*pi));
else
    IC=-2*LLL+2*N_par+2*N_par*(N_par+1)/(T-N_par-1);%-log(2*pi));
end
%LogL_cd=LogL_cd./T;
%fff=-LLL;%/T;
fff=fff*T;
end

