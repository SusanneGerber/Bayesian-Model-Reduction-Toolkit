function [ out] = AdaptiveBoxDiscretization_H1_EDBRM(in)


T=in.T;
N_alphaX=in.N_alphaX;
IC=in.IC;
K=in.K;
gamma=in.gamma_init;
eps1=in.eps1;
eps2=in.eps2;
i=1;
DeltaL=1e8;
optionsQP=optimset('MaxIter',1000,'Display','off','Algorithm','interior-point-convex');
options=optimset('GradObj','on','Algorithm','sqp','Display','off','MaxFunEvals',100000,'TolFun',1e-9,'TolX',1e-9,'MaxIter',300);

while and(i<in.MaxIter,abs(DeltaL)>in.tol)
    gamma_old=gamma;
    if abs(in.eps1)>1e-12
        tic;
        [P,gamma_xx,fff,IC,N_par,LLL] = PRP_measure_clustering_H1_EDBRM_reg(T,IC,gamma,...
            K,in.N_cd_old,in.P_init,options,in.eps1*full(in.H_g),(in.A_g),in.b_g,(in.Aeq_g),(in.beq_g));
        %time(i)=toc;
         in.P_init=P;
        xxx=reshape(gamma_xx,1,K*N_alphaX);
        acf(i)=LLL;
       tt(i)=toc;
    else
        %tic; 
        tic;
        [P,gamma_xx,fff,IC,N_par,LLL] = PRP_measure_clustering_H1_EDBRM(T,IC,gamma,K,in.N_cd_old,in.P_init,options);
        %time(i)=toc;
         in.P_init=P;
        xxx=reshape(gamma_xx,1,K*N_alphaX);
        acf(i)=LLL;
       tt(i)=toc;
    end
%    if f0>=acf(i)
        gamma=reshape(xxx,K,N_alphaX);
    %elseif i>1
    %    gamma=gamma_old;
    %    acf(i)=acf(i-1);
%    end
    %for t=1:N_alphaX
    %    [~,ii]=min(LogL_cd(:,t));
    %    gamma(t)=ii(1);
    %end
    if i>1
        DeltaL=acf(i-1)-acf(i);
    end
    i=i+1;
    %if DeltaL<-1e-7
    %    keyboard
    %end
end
out.gamma=gamma;
out.tt=mean(tt);
out.P=P;
out.IC=IC;
out.acf=acf;
out.N_par=N_par;
out.LogL=LLL;
%out.time=mean(time);