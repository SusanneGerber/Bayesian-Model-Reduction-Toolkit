function dist = KernelDistance(X,Y)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

%dist=sum(X([1:4])==Y([1:4]))>2;
%dist=(sum(X([2:4]))==sum(Y([2:4])));


%if X(1)==Y(1)
%  dist=1;
%else
%   dist=0; 
%end

% % if and(X(3)==1,Y(3)==1)
% %     dist=1;
% % elseif and(X(3)~=1,Y(3)~=1)
% %     dist=1;
% % else
% %     dist=0;
% % end

alpha=4;   
dist=exp(-alpha*sum((X-Y).^2));

%dist=sum(double(abs(X(3)-Y(3))==0))>=1;

%dist=sum(double(abs(X(3)-Y(3))));
end

