function [ L,dL] = LogLik_gamma_reg(x,N_cd_old,lambda,K,m,n,H)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
gamma=reshape(x,K,n);
s_l=lambda*gamma;
L=-sum(sum(N_cd_old.*log(s_l)))+x*H*x';
dL=zeros(K,n);
for i1=1:m
    for k1=1:K
        for n1=1:n
            dL(k1,n1)=dL(k1,n1)- N_cd_old(i1,n1)/(s_l(i1,n1))*lambda(i1,k1);
        end
    end
end
dL=reshape(dL,1,K*n)+2*(H*x')';
