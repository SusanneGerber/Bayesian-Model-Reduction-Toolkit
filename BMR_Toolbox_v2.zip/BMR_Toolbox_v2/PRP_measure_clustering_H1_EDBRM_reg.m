function [P,gamma,fff,IC,N_par,LLL] = PRP_measure_clustering_H1_EDBRM_reg(T,IC,gamma,K,N_cd_old,P_init,options,H,Aneq,bneq,Aeq,beq)

[m,n]=size(N_cd_old);
N_alphaX_old=n;

AneqL=-eye(m*K);bneqL=zeros(m*K,1);
t=1;AeqL=zeros(K,K*m);
for i=1:K
    AeqL(t,((i-1)*m+1):(i*m))=1;
    t=t+1;
end
beqL=ones(K,1);
x0=[reshape(P_init,1,m*K)];
[xxx,L_fin,flag,output] =  fmincon(@(x)LogLik_lambda...
        (x,N_cd_old,gamma,K,m,n)...
        ,x0,AneqL,bneqL,AeqL,beqL,[],[],[],options);
P=reshape(xxx,m,K);

x0=reshape(gamma,1,K*n);
[xxx,L_fin,flag,output] =  fmincon(@(x)LogLik_gamma_reg...
        (x,N_cd_old,P,K,m,n,H)...
        ,x0,Aneq,bneq,Aeq,beq,[],[],[],options); 
gamma=reshape(xxx,K,n);
PP=P*gamma;    
% N_par=0;npp=zeros(1,N_alphaY);
% for state_i=1:N_alphaY
%     pp=sort(P(state_i,:),'descend');
%     npp(state_i)=length(find(abs(diff(pp))>1e-8))+1;
%     N_par=N_par+npp(state_i);
% end
% xxx=reshape(gamma,1,K*N_alphaX_old);
N_par=(m-1)*K;%0.5*xxx*H_g*xxx';%N_par-min(npp);
LLL=0;
for i=1:m
    for j=1:n
    LLL=LLL-N_cd_old(i,j)*log(PP(i,j));
    end
end
if strcmp(IC,'BIC'),
    IC=-2*LLL+N_par*(log(T));%+2*N_par_cd;%+2*N_par_cd*(N_par_cd+1)/(T-N_par_cd-1);%-log(2*pi));
else
    IC=-2*LLL+2*N_par+2*N_par*(N_par+1)/(T-N_par-1);%-log(2*pi));
end
%LogL_cd=LogL_cd./T;
fff=-LLL;%/T;
end

