function [ lambda_f,Gamma_f, Lfin] = nnmf_Bayes_constrained_penalty(A,K)

%% Tykhonov-penalized Non-Negative Matrix Factorization in Frobhenius-norm for the Bayesian
%% causality matrix A,
%% with the matrix stochasticity constraints included as penalty terms (equality and inequality) 
%% and with the reduced rank-dimension K:
%% ||A-lambda_f*Gamma_f||+alpha||Id*lambda-1||+beta||Id*Gamma-1|| 
%% Based on the iterative scheme suggested in a Section 4 ("Application-Dependent Auxiliary Constraints")
%% of the paper: 
%% M. Berry et. al. "Algorithms and applications for approximate nonnegative matrix factorization",
%% Computational Statistics & Data Analysis, 52(1), 155 - 173, 2007  

MaxIter=10000;
N_anneal=1;
eps=1e-5;
[m,n]=size(A);
Id_m=ones(m);Id_K=ones(K);

%% Setting regularization parameters alpha and beta
%% Attention: If they are set too large then the fixed-point
%% iteration below will not converge 

alpha=7e-2;beta=7e-2;
L_fin=1e10;
for na=1:N_anneal
    lambda=rand(m,K);
    Gamma=rand(K,n);
    i=1;tol=10*eps;
    while and(i<=MaxIter,tol>eps)
        lambda=lambda.*(A*Gamma')./(lambda*Gamma*Gamma'+...
            alpha*2*(Id_m*lambda-ones(m,K))+1e-9);
        Gamma=Gamma.*(lambda'*A)./(lambda'*lambda*Gamma+...
            beta*2*(Id_K*Gamma-ones(K,n))+1e-9);
        L(i)=1/(m*n)*(norm(A-lambda*Gamma,'fro')+alpha*norm(Id_m*lambda-ones(m,K),'fro')...
            +beta*norm(Id_K*Gamma-ones(K,n),'fro'));
        if i>1
            tol=L(i-1)-L(i);
        end
        i=i+1;
    end
    if and(tol>0,L_fin>L(i-1))
        Lfin=L;
        L(i-1)
        lambda_f=lambda;
        Gamma_f=Gamma;
    end
end
na
figure;
subplot(2,1,1);plot(sum(lambda_f,1))
subplot(2,1,2);plot(sum(Gamma_f,1))
end

