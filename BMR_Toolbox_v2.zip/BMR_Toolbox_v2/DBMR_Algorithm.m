function [ Out,IC_all,N_par_all,LogL] = DBMR_Algorithm(X,Y,alphaX,N_alphaX,alphaY,N_alphaY,IC,K,eps1,eps2,St_Y)


%in.X=X;
%in.Y=Y;
in.T=size(X,2);
in.alphaX=alphaX;
in.N_alphaX=N_alphaX;
in.alphaY=alphaY;
in.N_alphaY=N_alphaY;
in.IC=IC;
in.K=K;
in.gamma_init=zeros(K,N_alphaX);
for t=1:N_alphaX
    rr=ceil(K*rand(1));
    in.gamma_init(rr,t)=1;
end
in.P_init=ones(N_alphaY,K)./N_alphaY;
in.MaxIter=1000;
in.tol=1e-7;
in.N_anneal=10;
in.eps2=eps2;
N_cd_old=zeros(N_alphaY,N_alphaX);
for state_i=1:N_alphaY
    for state_j=1:N_alphaX
        N_cd_old(state_i,state_j)=sum((Y==alphaY{state_i}).*(X==alphaX{state_j}));
    end
end
in.N_cd_old=N_cd_old;
A=-eye(N_alphaY*K);b=zeros(N_alphaY*K,1);
Aeq=zeros(K,N_alphaY*K);
for state_j=1:K
    for state_i=1:N_alphaY
        Aeq(state_j,state_j+K*(state_i-1))=1;
    end
end
beq=ones(K,1);

in.A=A;in.b=b;in.Aeq=Aeq;in.beq=beq;
[H_g,in.A_g,in.b_g,in.Aeq_g,in.beq_g,Out.H_D] = CreateMatricesForH1_Clustering(St_Y,N_alphaX,K);
for i=1:length(eps1)
    i
    in.H_g=H_g;
    in.eps1=eps1(i);
    [ AnnealOut{i}] = AnnealingForAdaptiveBoxDiscretization_H1_v2(in);
    in.gamma_init=AnnealOut{i}.gamma;
end

IC_all=zeros(1,length(eps2));N_par_all=IC_all;LogL=IC_all;
for i=1:length(eps2)
    IC_all(i)=AnnealOut{i}.IC;
    N_par_all(i)=AnnealOut{i}.N_par;
    LogL(i)=AnnealOut{i}.LogL;
end
[Out.IC,ii]=max(LogL);
Out.P=AnnealOut{ii}.P;
Out.gamma=AnnealOut{ii}.gamma;
Out.acf=AnnealOut{ii}.acf;
Out.N_par=AnnealOut{ii}.N_par;
Out.LogL=AnnealOut{ii}.LogL;
Out.H_g=H_g;