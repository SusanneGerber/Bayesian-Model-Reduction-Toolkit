function [ lambda_f,Gamma_f, L] = nnmf_Bayes_constrained_v2(A,K)

%% Non-Negative Matrix Factorization in Frobhenius-norm for the Bayesian
%% causality matrix A,
%% subject to the matrix stochasticity constraints (equality and inequality) 
%% and with the reduced rank-dimension K

%rand('seed',1)
N_anneal=1;
[m,n]=size(A);

Aeq=zeros(K+n,(m+n)*K);
beq=ones(K+n,1);
Aneq=-eye(K*(m+n));
bneq=zeros(K*(m+n),1);
t=1;
for i=1:K
   Aeq(t,(i-1)*m+1:i*m)=1; 
   t=t+1; 
end
for i=1:n
    Aeq(t,K*m+(i-1)*K+1:K*m+i*K)=1;
    t=t+1;
end
L=1e10;

options=optimset('GradObj','off','Algorithm','active-set','Display','off','MaxFunEvals',100000);

for na=1:N_anneal
     %lambda(1:2,:)=0.3*rand(2,K);lambda(3,:)=1-sum(lambda(1:2,:),1);
    Gamma=rand(K,n);Gamma=Gamma./(ones(K,K)*Gamma);
    lambda=rand(m,K);lambda=lambda./(ones(m,m)*lambda);

    %Gamma(1,:)=rand(1,n);Gamma(2,:)=1-Gamma(1,:);
    x0=[reshape(lambda,1,m*K) reshape(Gamma,1,n*K)];
    [xxx,L_fin,flag,output] =  fmincon(@(x)NMF_function...
        (x,A,n,m,K)...
        ,x0,Aneq,bneq,Aeq,beq,[],[],[],options);
    lambda=reshape(xxx(1:m*K),m,K);
    Gamma=reshape(xxx(1+m*K:m*K+K*n),K,n);
    if na==1
        L=L_fin;
        lambda_f=lambda;
        Gamma_f=Gamma;
    end
        
    L_fin
    if L_fin<L
        L=L_fin;
        lambda_f=lambda;
        Gamma_f=Gamma;
    end
end
% na
% figure;
% subplot(2,1,1);plot(sum(lambda_f,1))
% subplot(2,1,2);plot(sum(Gamma_f,1))
end

