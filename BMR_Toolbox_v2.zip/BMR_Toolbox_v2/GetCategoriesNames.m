function [alpha,N_alpha] = GetCategoriesNames(X)
% 
%   Detailed explanation goes here

[T,M]=size(X);

k=1;alpha=[];
for t=1:T
    for n=1:M
        if ~inset(X(t,n),alpha)
            alpha{k}=X(t,n);
            k=k+1;
        end
    end
end
N_alpha=numel(alpha);

aa=sort(cell2mat(alpha));
for i=1:N_alpha
    alpha{i}=aa(i);
end

